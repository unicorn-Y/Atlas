# Atlas Desktop V1.2 - Chat Review

## 交付内容

- source/：本次 Runtime Store、事件渲染、Artifact、Mock Runtime 与协议相关源码。
- docs/api-protocol-v1.2.md：Run、Event、Artifact、Approval、Resume 协议。
- images/Atlas-V1.2-runtime-accepted.png：Mock 任务完成后的界面截图。

## 架构与协议结果

- Runtime 状态以 AgentEvent 为主数据；Store 保存 runs、activeRunId、事件和 Artifact。
- Mock 直接发出 AgentEvent envelope，不再生成 WorkspaceMessage。
- Approval 通过 approval.response 返回 Runtime，Mock 中已观察到 approval.responded。
- 断线恢复游标记录 run_id 对应的最后事件序号，并使用 resume / after_sequence 请求回放。

## 验收

- npm run build：通过。
- Mock 页面实际操作：提交任务后观察到 run.started、tool.started、artifact.updated、approval.required；点击允许后收到 approval.responded 和 run.completed。完成时共 10 个有序事件。
- UI 页面结构与样式未修改。

## 后端边界

当前 core/atlas/server.py 仍是旧聊天 WebSocket 协议，尚未实现 V1.2 Runtime 事件、Approval 与 Resume 服务端端点。Mock 和前端协议已验证；真实后端需实现 V1.2 契约后才能使用该 Runtime 客户端。